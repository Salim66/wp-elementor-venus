<?php 
/**
 * Template Name: Venus Elementor
 */
the_post();
get_header();
echo "<div class='content-elementor'>";
the_content();
echo "</div>";
get_footer();
